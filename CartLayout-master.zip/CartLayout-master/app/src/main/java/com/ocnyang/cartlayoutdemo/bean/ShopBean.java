package com.ocnyang.cartlayoutdemo.bean;


import com.ocnyang.cartlayout.bean.GroupItemBean;

public class ShopBean extends GroupItemBean {
    String shop_name;

    public String getShop_name() {
        return shop_name;
    }

    public void setShop_name(String shop_name) {
        this.shop_name = shop_name;
    }
}
