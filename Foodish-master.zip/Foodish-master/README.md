# Foodish
An android shopping cart application for food items which pulls data from an API containing data in JSON format, and displays it with heterogeneous recyclerview.

![](1.PNG)
![](2.PNG)
![](3.PNG)
![](4.PNG)
![](5.PNG)
