package com.recyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import java.util.ArrayList;

public class RecyclerViewActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private LinearLayoutManager linearLayoutManager;
    private ArrayList<RecyclerViewItemModel> recyclerViewItemModelArrayList;
    private RecyclerViewAdapter recyclerViewAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_view);
        setRecyclerViewItem();
    }

    private void setRecyclerViewItem()
    {
        recyclerView =findViewById(R.id.sub_genre_recycler_view);
        recyclerViewItemModelArrayList = new ArrayList<>();

        linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerViewAdapter =new RecyclerViewAdapter(RecyclerViewActivity.this);
        recyclerView.setAdapter(recyclerViewAdapter);

        recyclerViewItemModelArrayList.add(new RecyclerViewItemModel("Acoustic Blues"));
        recyclerViewItemModelArrayList.add(new RecyclerViewItemModel("African Blues"));
        recyclerViewItemModelArrayList.add(new RecyclerViewItemModel("Blues Rock"));
        recyclerViewItemModelArrayList.add(new RecyclerViewItemModel("Blues Shouter"));
        recyclerViewItemModelArrayList.add(new RecyclerViewItemModel("British Blues"));
        recyclerViewItemModelArrayList.add(new RecyclerViewItemModel("Canadian Blues"));
        recyclerViewItemModelArrayList.add(new RecyclerViewItemModel("Chicago Blues"));
        recyclerViewItemModelArrayList.add(new RecyclerViewItemModel("Classic Blues"));
        recyclerViewItemModelArrayList.add(new RecyclerViewItemModel("Classic Female Blues"));
        recyclerViewItemModelArrayList.add(new RecyclerViewItemModel("Contemporary Blues"));
        recyclerViewItemModelArrayList.add(new RecyclerViewItemModel("Contemporary R&B"));
        recyclerViewItemModelArrayList.add(new RecyclerViewItemModel("Country Blues"));
        recyclerViewItemModelArrayList.add(new RecyclerViewItemModel("Delta Blues"));
        recyclerViewItemModelArrayList.add(new RecyclerViewItemModel("Detroit Blues"));
        recyclerViewItemModelArrayList.add(new RecyclerViewItemModel("Electric Blues"));
        recyclerViewItemModelArrayList.add(new RecyclerViewItemModel("Folk Blues"));
        recyclerViewItemModelArrayList.add(new RecyclerViewItemModel("Gospel Blues"));
        recyclerViewItemModelArrayList.add(new RecyclerViewItemModel("Harmonica Blues"));
        recyclerViewItemModelArrayList.add(new RecyclerViewItemModel("Hill Country Blues"));
        recyclerViewItemModelArrayList.add(new RecyclerViewItemModel("Hokum Blues"));
        recyclerViewItemModelArrayList.add(new RecyclerViewItemModel("Jazz Blues"));
        recyclerViewItemModelArrayList.add(new RecyclerViewItemModel("Jump Blues"));
        recyclerViewItemModelArrayList.add(new RecyclerViewItemModel("Kansas City Blues"));
        recyclerViewItemModelArrayList.add(new RecyclerViewItemModel("Louisiana Blues"));
        recyclerViewItemModelArrayList.add(new RecyclerViewItemModel("Memphis Blues"));

        recyclerViewAdapter.setAdapterListData(recyclerViewItemModelArrayList);
        recyclerViewAdapter.notifyDataSetChanged();
    }
}
