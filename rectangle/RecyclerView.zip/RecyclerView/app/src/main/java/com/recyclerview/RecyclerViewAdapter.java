package com.recyclerview;

import android.content.Context;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ItemViewHolder> {

    private static final String TAG = RecyclerViewAdapter.class.getSimpleName();
    private Context context;
    private LayoutInflater layoutInflater;
    private List<RecyclerViewItemModel> itemList;
    private SparseBooleanArray sparseBooleanArray;

    public RecyclerViewAdapter(Context context) {
        this.context = context;
        itemList = new ArrayList<>();
        sparseBooleanArray = new SparseBooleanArray();
        layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public void setAdapterListData(List<RecyclerViewItemModel> recyclerViewItemModelArrayList) {
        this.itemList = recyclerViewItemModelArrayList;
    }

    public List<RecyclerViewItemModel> getAdapterListData() {
        return this.itemList;
    }

    @Override
    public int getItemCount() {
        return itemList == null ? 0 : itemList.size();
    }

    public boolean isAdapterListEmpty() {
        return getItemCount() == 0;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = layoutInflater.inflate(R.layout.sub_genre_row, parent, false);
        ItemViewHolder itemViewHolder = new ItemViewHolder(view);
        return itemViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder itemViewHolder, final int position) {
        RecyclerViewItemModel currentItem = itemList.get(position);
        ((ItemViewHolder) itemViewHolder).setData(currentItem,position);
    }

    /**
     * Select all checkbox
     **/
    public void selectAll() {
        LogUtility.debuggingMessage(TAG, "selectAll() : " + itemList);
    }

    /**
     * Remove all checkbox
     **/
    public void deselectAll()
    {
        LogUtility.debuggingMessage(TAG, "deselectAll() : " + itemList);
        List<Integer> selection = getSelectedItems();
        sparseBooleanArray.clear();
        for (Integer i : selection) {
            notifyItemChanged(i);
        }
    }

    /**
     * Check the Checkbox if not checked, if already check then unchecked
     **/
    public void checkCheckBox(int position, boolean value)
    {
        if (value)
        {
            sparseBooleanArray.put(position, true);
        }
        else
        {
            sparseBooleanArray.delete(position);
        }
        LogUtility.debuggingMessage(TAG, "selectAll() : " +sparseBooleanArray);
        notifyItemChanged(position);
    }

    /**
     * Return the selected Checkbox position
     **/
    public SparseBooleanArray getSelectedIds() {
        return sparseBooleanArray;
    }

    /**
     * Count the selected items
     * @return Selected items count
     */
    public int getSelectedItemCount() {
        return sparseBooleanArray.size();
    }

    /**
     * Indicates the list of selected items
     * @return List of selected items ids
     */
    public List<Integer> getSelectedItems()
    {
        List<Integer> items = new ArrayList<>(sparseBooleanArray.size());

        for (int i = 0; i < sparseBooleanArray.size(); ++i)
        {
            items.add(sparseBooleanArray.keyAt(i));
        }
        return items;
    }

    /**
     * Indicates if the item at position position is selected
     * @param position Position of the item to check
     * @return true if the item is selected, false otherwise
     */
    public boolean isSelected(int position) {
        return getSelectedItems().contains(position);
    }


    public void removeItem(int position) {
        itemList.remove(position);
        notifyItemRemoved(position);
    }

    private void removeRange(int positionStart, int itemCount) {
        for (int i = 0; i < itemCount; ++i) {
            itemList.remove(positionStart);
        }
        notifyItemRangeRemoved(positionStart, itemCount);
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {
        private ImageView itemImageView;
        private TextView itemFirstTextView;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            itemImageView = itemView.findViewById(R.id.event_icon_right_arrow_image_view);
            itemFirstTextView = itemView.findViewById(R.id.sub_genre_name_text_view);
        }

        public void setData(RecyclerViewItemModel recyclerViewItemModel, int position) {
            itemFirstTextView.setText(recyclerViewItemModel.getFirstTitle());

            if(isSelected(position))
            {
                itemImageView.setImageResource(R.drawable.ic_sub_genre_check);
            }
            else
            {
                itemImageView.setImageResource(R.drawable.ic_sub_genre_uncheck);
            }

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    RecyclerViewItemModel currentRecyclerViewItem = itemList.get(position);
                    checkCheckBox(position, !(isSelected(position)));
                }
            });

            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    RecyclerViewItemModel currentRecyclerViewItem = itemList.get(position);
                    checkCheckBox(position, !(isSelected(position)));
                    return true;
                }
            });
        }
    }
}
