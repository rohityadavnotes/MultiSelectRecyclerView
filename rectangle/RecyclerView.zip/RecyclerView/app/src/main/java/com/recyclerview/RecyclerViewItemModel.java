package com.recyclerview;

public class RecyclerViewItemModel {

    private String firstTitle;

    public RecyclerViewItemModel(String firstTitle) {
        this.firstTitle = firstTitle;
    }

    public String getFirstTitle() {
        return firstTitle;
    }

    public void setFirstTitle(String firstTitle) {
        this.firstTitle = firstTitle;
    }
}